def add(a, b):
    """Simple add function used for testing."""
    return a + b


def subtract(a, b):
    """Simple subtract function to show we can add more logic."""
    return a - b


if __name__ == "__main__":
    print("App is running")
    print("2 + 3 =", add(2, 3))
    print("5 - 1 =", subtract(5, 1))
